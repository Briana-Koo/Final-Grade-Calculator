//
//  Final_Grade_CalculatorApp.swift
//  Final Grade Calculator
//
//  Created by Student on 9/13/21.
//

import SwiftUI

@main
struct Final_Grade_CalculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
